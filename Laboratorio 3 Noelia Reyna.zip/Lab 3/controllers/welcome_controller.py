from flask import Blueprint, render_template, request
import os

template_dir = os.path.abspath('views')
index_page = Blueprint('index_page', 'api', template_folder=template_dir)

@index_page.route('/', methods=['GET'])
def index():
    return render_template('welcome/index.html')