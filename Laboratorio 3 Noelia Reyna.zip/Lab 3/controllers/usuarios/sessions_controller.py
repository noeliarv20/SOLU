from flask import Blueprint, render_template
import os

template_dir = os.path.abspath('app/views')
sessions_page = Blueprint('sessions_page', 'api', template_folder=template_dir)

@sessions_page.route('/login', methods=['GET'])
def new():
    return render_template('usuarios/sessions/new.html')