from flask import Flask

def register_blueprints(application):
    """Recibe un objeto de clase Flask. Importa los blueprints creados en los controladores"""
    from controllers.welcome_controller import index_page
    from controllers.usuarios.registrations_controller import registration_page
    from controllers.usuarios.sessions_controller import sessions_page
    application.register_blueprint(index_page)
    application.register_blueprint(registration_page)
    application.register_blueprint(sessions_page)

def create_app(config_filename=None):
    application = Flask(__name__, instance_relative_config=True)
    application.config.from_object(config_filename)
    register_blueprints(application)
    return application

app = Flask(__name__)
app = create_app('config')